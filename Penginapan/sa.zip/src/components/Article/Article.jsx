import { useState } from "react";
import Cari from "../search/search";
import List from "../List-Kamar/List";

const Article = ({ data = [] }) => {
  const [filteredData, setFilteredData] = useState(data);
  const [dataTotal, setDataTotal] = useState(data.length);

  const onChangeSearch = (searchTerm) => {
    const filteredData = data.filter((data) => {
      return data.jenis_kamar.toLowerCase().includes(searchTerm.toLowerCase());
    });
    setFilteredData(filteredData);
    setDataTotal(filteredData.length);
  };

  return (
    <div>
      <Cari dataTotal={dataTotal} onChangeSearch={onChangeSearch} />
      <div className="wrapper">
        {filteredData.length > 0 ? (
          filteredData.map((dta, index) => (
            <div className="card" key={index}>
              <div className="card-h">
                <img src={Logo1} alt="" width={300} />
              </div>
              <div className="card-b">
                <List
                  JenisKamar={dta.jenis_kamar}
                  Harga={dta.harga}
                  Fasilitas={dta.fasilitas}
                />
              </div>
            </div>
          ))
        ) : (
          <p>Data tidak ditemukan</p>
        )}
      </div>
    </div>
  );
};

export default Article;
