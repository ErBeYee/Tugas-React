import Header from "./components/Header/Header";
import Footer from "./components/Footer/Footer";
import List from "./components/List-Kamar/List";
import Logo1 from "./components/IMG/_ (3).jpeg";
// import Logo2 from "./components/IMG/95261389e5374350a146c247279c34b7.jpg";
// import Logo3 from "./components/IMG/Bamboo Beach Hotel.jpeg";
// import Logo4 from "./components/IMG/Budget Hotel Interior Design ideas 07.jpeg";
import "./App.css";
import Cari from "./components/search/search";
import data from "./data.json";
import Article from "./components/Article/Article";
import { useState } from "react";

function App() {
  return (
    <>
      <div className="bg">
        <Header />
      </div>
      <div className="bnkus">
        <div className="pl">
          <h3>Pilih kamar impian anda disini</h3>
        </div>
        <Article />
      </div>
      <div className="foot">
        <Footer Nama={"BillHaven"} />
      </div>
    </>
  );
}

export default App;
